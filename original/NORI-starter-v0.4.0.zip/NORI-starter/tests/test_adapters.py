from app.game.adapters import adapter_status

def test_real_game_adapters_are_disabled_until_authorized_source_exists():
    statuses = adapter_status()["adapters"]
    assert len(statuses) == 2
    assert all(item["enabled"] is False for item in statuses)
