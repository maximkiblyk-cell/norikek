"""Local development API. Not production-ready; see docs/STATUS.md."""
from contextlib import asynccontextmanager
import hmac
import hashlib
from fastapi import FastAPI, Depends, Header, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from app.db import Base, engine, get_db
from app.models import User, License, NotificationSetting, SupportTicket, SupportTicketRequest
from app.schemas import RegisterUser, PairingCreate, PairingConfirm, SettingUpdate, TicketCreate, Platform, Kind
from app.core.config import settings
from app.game.adapters import adapter_status
from app.licenses import router as license_router
from app.support import router as support_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)  # local starter only; not a migration system
    yield

app = FastAPI(title="NØRI API — development", version="0.4.0", lifespan=lifespan)

def require_service(authorization: str | None = Header(default=None)):
    if not settings.service_token:
        raise HTTPException(503, "Service token not configured")
    expected = "Bearer " + settings.service_token
    if not authorization or not hmac.compare_digest(authorization.encode(), expected.encode()):
        raise HTTPException(401, "Invalid service credentials")

def user_for(db: Session, telegram_id: int):
    user = db.query(User).filter_by(telegram_id=telegram_id).first()
    if not user:
        raise HTTPException(404, "User not registered")
    return user

@app.get("/health")
def health():
    return {"status": "ok", "service": settings.app_name}

@app.post("/v1/users", dependencies=[Depends(require_service)])
def register_user(payload: RegisterUser, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(telegram_id=payload.telegram_id).first()
    if user is None:
        user = User(telegram_id=payload.telegram_id, username=payload.username)
        db.add(user)
    else:
        user.username = payload.username
    db.commit()
    db.refresh(user)
    return {"user_id": user.id, "telegram_id": user.telegram_id, "created_at": user.created_at}

@app.get("/v1/users/{telegram_id}", dependencies=[Depends(require_service)])
def account(telegram_id: int, db: Session = Depends(get_db)):
    user = user_for(db, telegram_id)
    license_row = db.query(License).filter_by(user_id=user.id).order_by(License.id.desc()).first()
    return {"telegram_id": user.telegram_id, "username": user.username, "created_at": user.created_at,
            "license": {"active": license_row.active, "expires_at": license_row.expires_at} if license_row else None,
            "devices": None}

@app.post("/v1/pairing", dependencies=[Depends(require_service)])
def create_pairing(payload: PairingCreate):
    # Previous implementation created unauthenticated, plaintext codes without binding a device.
    raise HTTPException(503, "Pairing disabled: secure device binding is not implemented")

@app.post("/v1/pairing/confirm", dependencies=[Depends(require_service)])
def confirm_pairing(payload: PairingConfirm):
    raise HTTPException(503, "Pairing disabled: secure device binding is not implemented")

@app.get("/v1/game/adapters", dependencies=[Depends(require_service)])
def game_adapters():
    return adapter_status()

@app.get("/v1/users/{telegram_id}/settings", dependencies=[Depends(require_service)])
def get_settings(telegram_id: int, db: Session = Depends(get_db)):
    user = user_for(db, telegram_id)
    rows = db.query(NotificationSetting).filter_by(user_id=user.id).all()
    return {"settings": [{"platform": r.platform, "kind": r.kind, "enabled": r.enabled} for r in rows]}

@app.put("/v1/users/{telegram_id}/settings/{platform}/{kind}", dependencies=[Depends(require_service)])
def set_setting(telegram_id: int, platform: Platform, kind: Kind, body: SettingUpdate, db: Session = Depends(get_db)):
    user = user_for(db, telegram_id)
    row = db.query(NotificationSetting).filter_by(user_id=user.id, platform=platform, kind=kind).first()
    if row is None:
        row = NotificationSetting(user_id=user.id, platform=platform, kind=kind, enabled=body.enabled)
        db.add(row)
    else:
        row.enabled = body.enabled
    db.commit()
    return {"platform": platform, "kind": kind, "enabled": row.enabled}

@app.post("/v1/users/{telegram_id}/tickets", dependencies=[Depends(require_service)], status_code=201)
def create_ticket(telegram_id: int, body: TicketCreate, db: Session = Depends(get_db)):
    user = user_for(db, telegram_id)
    message = body.message.strip()
    if not message:
        raise HTTPException(422, "Message cannot be blank")
    request_id = str(body.request_id) if body.request_id else None
    digest = hashlib.sha256(message.encode("utf-8")).hexdigest()
    def replay():
        prior = db.get(SupportTicketRequest, request_id) if request_id else None
        if prior is None:
            return None
        if (prior.user_id, prior.category, prior.message_hash) != (user.id, body.category, digest):
            raise HTTPException(409, "Request ID conflict")
        ticket = db.get(SupportTicket, prior.ticket_id)
        return {"id": ticket.id, "status": ticket.status, "created_at": ticket.created_at, "replayed": True}
    previous = replay()
    if previous:
        return previous
    row = SupportTicket(user_id=user.id, category=body.category, message=message)
    db.add(row)
    try:
        db.flush()
        if request_id:
            db.add(SupportTicketRequest(request_id=request_id, ticket_id=row.id, user_id=user.id, category=body.category, message_hash=digest))
        db.commit()
    except IntegrityError:
        db.rollback()
        previous = replay()
        if previous:
            return previous
        raise HTTPException(409, "Request ID conflict")
    db.refresh(row)
    return {"id": row.id, "status": row.status, "created_at": row.created_at, "replayed": False}

@app.get("/v1/users/{telegram_id}/tickets", dependencies=[Depends(require_service)])
def list_tickets(telegram_id: int, db: Session = Depends(get_db)):
    user = user_for(db, telegram_id)
    rows = db.query(SupportTicket).filter_by(user_id=user.id).order_by(SupportTicket.id.desc()).limit(20).all()
    return {"tickets": [{"id": r.id, "category": r.category, "status": r.status, "created_at": r.created_at} for r in rows]}

# Trust boundary: only the configured bot service may invoke these routes.
app.include_router(license_router, dependencies=[Depends(require_service)])

app.include_router(support_router, dependencies=[Depends(require_service)])
