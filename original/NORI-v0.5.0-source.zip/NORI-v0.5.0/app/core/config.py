from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "NØRI"
    database_url: str = "sqlite:///./nori.db"
    bot_token: str = ""
    api_base_url: str = "http://127.0.0.1:8000"
    # Shared server-to-bot credential; do not distribute to game clients.
    service_token: str = ""
    admin_telegram_ids: str = ""  # comma-separated IDs; empty denies all admin actions
    pairing_ttl_seconds: int = 300
    device_pairing_enabled: bool = False  # enable only in isolated test environment
    device_limit: int = 2
    auto_create_schema: bool = True
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
