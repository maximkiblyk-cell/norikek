from datetime import datetime, timezone, timedelta
from secrets import choice
from string import digits, ascii_uppercase
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import Base, engine, get_db
from app.models import User, PairingCode
from app.schemas import RegisterUser, PairingCreate, PairingConfirm
from app.core.config import settings
from app.game.adapters import adapter_status

Base.metadata.create_all(bind=engine)
app = FastAPI(title="NØRI API", version="0.1.0")

@app.get("/health")
def health():
    return {"status": "ok", "service": settings.app_name}

@app.post("/v1/users")
def register_user(payload: RegisterUser, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(telegram_id=payload.telegram_id).first()
    if user is None:
        user = User(telegram_id=payload.telegram_id, username=payload.username)
        db.add(user)
    else:
        user.username = payload.username
    db.commit(); db.refresh(user)
    return {"user_id": user.id, "telegram_id": user.telegram_id, "created_at": user.created_at}

@app.post("/v1/pairing")
def create_pairing(payload: PairingCreate, db: Session = Depends(get_db)):
    code = "".join(choice(ascii_uppercase + digits) for _ in range(8))
    row = PairingCode(code=code, platform=payload.platform,
                      expires_at=datetime.now(timezone.utc) + timedelta(seconds=settings.pairing_ttl_seconds))
    db.add(row); db.commit()
    return {"code": code, "platform": payload.platform, "expires_in": settings.pairing_ttl_seconds,
            "note": "Starter pairing record only; production device authentication is not implemented."}

@app.post("/v1/pairing/confirm")
def confirm_pairing(payload: PairingConfirm, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(telegram_id=payload.telegram_id).first()
    if user is None:
        raise HTTPException(404, "Telegram user is not registered")
    row = db.query(PairingCode).filter_by(code=payload.code, consumed=False).first()
    if row is None or row.expires_at.replace(tzinfo=timezone.utc) < datetime.now(timezone.utc):
        raise HTTPException(400, "Pairing code is invalid or expired")
    row.consumed = True
    db.commit()
    return {"status": "pairing_code_confirmed", "platform": row.platform,
            "note": "Device binding is not complete in this starter build."}

@app.get("/v1/game/adapters")
def game_adapters():
    return adapter_status()
