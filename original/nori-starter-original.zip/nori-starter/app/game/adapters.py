"""Game adapters deliberately remain disabled until an authorized SDK/API is verified."""

class DisabledAdapter:
    def __init__(self, platform: str): self.platform = platform
    @property
    def enabled(self) -> bool: return False
    def status(self):
        return {"platform": self.platform, "enabled": False,
                "reason": "No verified, authorized game event interface configured."}

HassleAdapter = DisabledAdapter("hassle")
RadmirAdapter = DisabledAdapter("radmir")

def adapter_status():
    return {"adapters": [HassleAdapter("hassle").status(), RadmirAdapter("radmir").status()]}
