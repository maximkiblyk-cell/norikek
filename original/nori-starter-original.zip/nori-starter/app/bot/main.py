import asyncio
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from app.core.config import settings

bot = Bot(token=settings.bot_token) if settings.bot_token else None
dp = Dispatcher()

def main_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎮 Подключить игру", callback_data="connect")],
        [InlineKeyboardButton(text="👤 Мой аккаунт", callback_data="account"), InlineKeyboardButton(text="🔔 Уведомления", callback_data="notifications")],
        [InlineKeyboardButton(text="💎 Подписка", callback_data="subscription"), InlineKeyboardButton(text="📱 Устройства", callback_data="devices")],
        [InlineKeyboardButton(text="📚 Инструкция", callback_data="help"), InlineKeyboardButton(text="🛟 Поддержка", callback_data="support")],
    ])

@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(
        "🖤 <b>NØRI — GAMING ECOSYSTEM</b>\n\n"
        "Добро пожаловать! Управляй подключением Hassle RP и Radmir CRMP, лицензией и уведомлениями прямо здесь.\n\n"
        "🎮 Игра: не подключена\n📡 Статус: ожидает настройки\n💎 Подписка: не проверена\n\n"
        "Выбери нужный раздел:", reply_markup=main_keyboard(), parse_mode="HTML")

@dp.callback_query(F.data == "connect")
async def connect(call: CallbackQuery):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎮 Hassle RP 2.0", callback_data="platform_hassle")],
        [InlineKeyboardButton(text="🎮 Radmir CRMP", callback_data="platform_radmir")],
        [InlineKeyboardButton(text="◀️ Главное меню", callback_data="home")]])
    await call.message.edit_text("🎮 <b>ПОДКЛЮЧЕНИЕ ИГРЫ</b>\n\nВыбери платформу:", reply_markup=kb, parse_mode="HTML")
    await call.answer()

@dp.callback_query(F.data.startswith("platform_"))
async def platform(call: CallbackQuery):
    name = "Hassle RP 2.0" if call.data.endswith("hassle") else "Radmir CRMP"
    await call.message.edit_text(
        f"🎮 <b>{name}</b>\n\nПодключение появится после реализации и проверки разрешённого игрового интерфейса.\n\n"
        "Сейчас реальная игровая интеграция отключена — бот не будет выдавать тестовые данные за настоящие.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="◀️ Назад", callback_data="connect")]]),
        parse_mode="HTML")
    await call.answer()

@dp.callback_query(F.data == "account")
async def account(call: CallbackQuery):
    await call.message.edit_text("👤 <b>МОЙ АККАУНТ</b>\n\nTelegram ID: <code>{}</code>\n🎮 Игра: не подключена\n💎 Лицензия: не проверена\n📱 Устройства: 0".format(call.from_user.id), reply_markup=main_keyboard(), parse_mode="HTML")
    await call.answer()

@dp.callback_query(F.data == "notifications")
async def notifications(call: CallbackQuery):
    await call.message.edit_text("🔔 <b>УВЕДОМЛЕНИЯ</b>\n\nНастройки станут доступны после подключения реального источника игровых событий.", reply_markup=main_keyboard(), parse_mode="HTML")
    await call.answer()

@dp.callback_query(F.data == "subscription")
async def subscription(call: CallbackQuery):
    await call.message.edit_text("💎 <b>ПОДПИСКА NØRI</b>\n\nСистема тарифов и оплаты пока не подключена. Не отправляй платежи через этот тестовый бот.", reply_markup=main_keyboard(), parse_mode="HTML")
    await call.answer()

@dp.callback_query(F.data == "devices")
async def devices(call: CallbackQuery):
    await call.message.edit_text("📱 <b>МОИ УСТРОЙСТВА</b>\n\nПока нет подтверждённых привязанных устройств.", reply_markup=main_keyboard(), parse_mode="HTML")
    await call.answer()

@dp.callback_query(F.data.in_({"help", "support"}))
async def help_support(call: CallbackQuery):
    await call.message.edit_text("🛟 <b>ПОДДЕРЖКА NØRI</b>\n\nЭто стартовая сборка. Обращения и база инструкций ещё не подключены.", reply_markup=main_keyboard(), parse_mode="HTML")
    await call.answer()

@dp.callback_query(F.data == "home")
async def home(call: CallbackQuery):
    await call.message.edit_text("🖤 <b>NØRI — GAMING ECOSYSTEM</b>\n\nВыбери нужный раздел:", reply_markup=main_keyboard(), parse_mode="HTML")
    await call.answer()

async def main():
    if not settings.bot_token:
        raise RuntimeError("BOT_TOKEN is empty. Add a TEST bot token to .env")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
