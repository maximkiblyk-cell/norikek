from pydantic import BaseModel, Field

class RegisterUser(BaseModel):
    telegram_id: int
    username: str | None = None

class PairingCreate(BaseModel):
    platform: str = Field(pattern="^(hassle|radmir)$")

class PairingConfirm(BaseModel):
    code: str
    telegram_id: int
