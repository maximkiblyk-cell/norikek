from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "NØRI"
    database_url: str = "sqlite:///./nori.db"
    bot_token: str = ""
    api_base_url: str = "http://127.0.0.1:8000"
    pairing_ttl_seconds: int = 300
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
