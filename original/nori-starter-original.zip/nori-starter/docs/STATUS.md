# Implementation status

## Implemented in this starter
- FastAPI health endpoint.
- Basic Telegram user registration model and endpoint.
- Pairing code creation and one-time confirmation primitive.
- Standard Telegram bot with inline navigation (no Mini App).
- Explicitly disabled Hassle and Radmir adapter stubs.

## Not implemented
- Actual in-game DLL/plugin and overlay.
- Real Hassle/Radmir event sources and command execution.
- Production-grade device credentials and authenticated device protocol.
- SMS/call/queue delivery worker.
- License key issuance and payment provider.
- Admin workflows, support ticket persistence, subscription billing.
- Production migrations, PostgreSQL/Redis deployment, signed updater.

These gaps require further implementation and, for game integration, verified authorized SDK/API documentation or permission from the game operator.
