# 🖤 NØRI — Starter Codebase

Fresh starter implementation for the NØRI ecosystem:
- Telegram bot (standard Telegram chat + inline keyboards; no Mini App)
- FastAPI backend
- SQLite local development database
- Pairing and license primitives
- Disabled Hassle/Radmir adapters until an authorized integration interface is verified

## Requirements
- Python 3.11+
- A Telegram bot token from BotFather (optional for API-only run)

## Quick start (Windows PowerShell)
```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
# Put your test bot token into .env
uvicorn app.main:app --reload
# In another terminal:
python -m app.bot.main
```

## Quick start (Linux/macOS)
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
python -m app.bot.main
```

API health: http://127.0.0.1:8000/health

## Current honest status
- Telegram menu and account/status views: implemented.
- Backend health, user registration, license status, pairing-code creation/confirmation: starter implementation.
- Real Hassle RP 2.0 and Radmir CRMP event ingestion: NOT implemented; adapters intentionally disabled.
- SMS/calls/queue notifications: require a verified, authorized game event source.
- Payments, production auth, production deployment hardening: not implemented.

Never put production secrets in source control. Use a separate test bot token first.
